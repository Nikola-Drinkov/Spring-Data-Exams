package softuni.exam.models.entity;

public enum CarTypes {
    SUV, coupe, sport
}
