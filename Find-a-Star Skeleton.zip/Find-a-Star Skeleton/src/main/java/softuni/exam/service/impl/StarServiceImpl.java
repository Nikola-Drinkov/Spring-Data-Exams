package softuni.exam.service.impl;

import com.google.gson.Gson;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;
import softuni.exam.models.dto.StarExportDTO;
import softuni.exam.models.dto.StarImportDTO;
import softuni.exam.models.entity.Constellation;
import softuni.exam.models.entity.Star;
import softuni.exam.models.entity.StarType;
import softuni.exam.repository.ConstellationRepository;
import softuni.exam.repository.StarRepository;
import softuni.exam.service.StarService;
import softuni.exam.util.ValidationUtils;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import static softuni.exam.util.Constants.*;
import static softuni.exam.util.Constants.SUCCESSFUL_CONSTELLATION;

// TODO: Implement all methods
@Service
public class StarServiceImpl implements StarService {
    private final ConstellationRepository constellationRepository;
    private final StarRepository starRepository;
    private final Gson gson;
    private final ModelMapper modelMapper;
    private final ValidationUtils validationUtils;

    public StarServiceImpl(ConstellationRepository constellationRepository, StarRepository starRepository, Gson gson, ModelMapper modelMapper, ValidationUtils validationUtils) {
        this.constellationRepository = constellationRepository;
        this.starRepository = starRepository;
        this.gson = gson;
        this.modelMapper = modelMapper;
        this.validationUtils = validationUtils;
    }

    @Override
    public boolean areImported() {
        return this.starRepository.count()>0;
    }

    @Override
    public String readStarsFileContent() throws IOException {
        return Files.readString(Path.of(STARS_URL));
    }

    @Override
    public String importStars() throws IOException {
        StringBuilder sb = new StringBuilder();
        List<StarImportDTO> starImportDTOS = Arrays.stream(gson.fromJson(readStarsFileContent(), StarImportDTO[].class)).collect(Collectors.toList());
        for (StarImportDTO starImportDTO : starImportDTOS) {

            Optional<Star> starOptional = this.starRepository.findFirstByName(starImportDTO.getName());
            String starType = starImportDTO.getStarType();

            if(!starType.equals("RED_GIANT") && !starType.equals("WHITE_DWARF") && !starType.equals("NEUTRON_STAR")){
                sb.append(String.format(INVALID_FORMAT, STAR));
            }
            else if (starOptional.isPresent() || !validationUtils.isValid(starImportDTO)) {
                sb.append(String.format(INVALID_FORMAT, STAR));
            } else {
                Constellation constellationToMap = this.constellationRepository.findFirstById(starImportDTO.getConstellation());
                Star star = modelMapper.map(starImportDTO, Star.class);
                star.setConstellation(constellationToMap);
                star.setStarType(StarType.valueOf(starType));

                this.starRepository.save(star);

                String format = String.format(SUCCESSFUL_STAR, star.getName(), star.getLightYears());
                format = format.replaceAll(",", ".");
                sb.append(format);
            }
            sb.append(System.lineSeparator());
        }

        return sb.toString();
    }

    @Override
    public String exportStars() {
        StringBuilder sb = new StringBuilder();
        List<Star> stars = this.starRepository.findAllByStarTypeAndObserversIsEmptyOrderByLightYears(StarType.RED_GIANT);
        for(Star star : stars){
            StarExportDTO starExportDTO = new StarExportDTO(star.getName(),star.getLightYears(), star.getDescription(), star.getConstellation().getName());
            sb.append(starExportDTO.toString().replaceAll(",","."));
        }
        return sb.toString();
    }
}
