package softuni.exam.service.impl;

import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;
import softuni.exam.models.dto.AstronomerImportDTO;
import softuni.exam.models.dto.AstronomerWrapper;
import softuni.exam.models.entity.Astronomer;
import softuni.exam.models.entity.Star;
import softuni.exam.repository.AstronomerRepository;
import softuni.exam.repository.StarRepository;
import softuni.exam.service.AstronomerService;
import softuni.exam.util.ValidationUtils;
import softuni.exam.util.XmlParser;

import javax.xml.bind.JAXBException;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static softuni.exam.util.Constants.*;

// TODO: Implement all methods
@Service
public class AstronomerServiceImpl implements AstronomerService {
    private final AstronomerRepository astronomerRepository;
    private final StarRepository starRepository;
    private final ModelMapper modelMapper;
    private final XmlParser xmlParser;
    private final ValidationUtils validationUtils;

    public AstronomerServiceImpl(AstronomerRepository astronomerRepository, StarRepository starRepository, ModelMapper modelMapper, XmlParser xmlParser, ValidationUtils validationUtils) {
        this.astronomerRepository = astronomerRepository;
        this.starRepository = starRepository;
        this.modelMapper = modelMapper;
        this.xmlParser = xmlParser;
        this.validationUtils = validationUtils;
    }

    @Override
    public boolean areImported() {
        return this.astronomerRepository.count()>0;
    }

    @Override
    public String readAstronomersFromFile() throws IOException {
        return Files.readString(Path.of(ASTRONOMERS_URL));
    }

    @Override
    public String importAstronomers() throws IOException, JAXBException {
        StringBuilder sb = new StringBuilder();
        List<AstronomerImportDTO> astronomerImportDTOS = xmlParser.fromFile(Path.of(ASTRONOMERS_URL).toFile(), AstronomerWrapper.class).getAstronomerImportDTOS();
        for (AstronomerImportDTO astronomerImportDTO : astronomerImportDTOS){
            Optional<Astronomer> astronomerOptional = this.astronomerRepository.findFirstByFirstNameAndLastName(astronomerImportDTO.getFirstName(),astronomerImportDTO.getLastName());
            Optional<Star> starOptional = this.starRepository.findFirstById(astronomerImportDTO.getObservingStar());

            if(astronomerOptional.isPresent() || starOptional.isEmpty() || !validationUtils.isValid(astronomerImportDTO)){
                sb.append(String.format(INVALID_FORMAT, ASTRONOMER));
            }
            else{
                int[] dateParts = Arrays.stream(astronomerImportDTO.getBirthday().split("-")).mapToInt(Integer::parseInt).toArray();
                int year = dateParts[0];
                int month = dateParts[1];
                int day = dateParts[2];
                LocalDate dateToMap = LocalDate.of(year,month,day);

                Astronomer astronomerToSave = modelMapper.map(astronomerImportDTO, Astronomer.class);
                astronomerToSave.setBirthday(dateToMap);
                astronomerToSave.setObservingStar(starOptional.get());

                this.astronomerRepository.save(astronomerToSave);
                String format = String.format(SUCCESSFUL_ASTRONOMER, astronomerToSave.getFirstName(), astronomerToSave.getLastName(), astronomerToSave.getAverageObservationHours());
                format = format.replaceAll(",",".");
                sb.append(format);
            }
            sb.append(System.lineSeparator());
        }
        return sb.toString();
    }
}
