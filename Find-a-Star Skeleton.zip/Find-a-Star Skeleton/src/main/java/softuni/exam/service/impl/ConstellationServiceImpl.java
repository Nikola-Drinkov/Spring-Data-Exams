package softuni.exam.service.impl;

import com.google.gson.Gson;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;
import softuni.exam.models.dto.ConstellationImportDTO;
import softuni.exam.models.entity.Constellation;
import softuni.exam.repository.ConstellationRepository;
import softuni.exam.service.ConstellationService;
import softuni.exam.util.ValidationUtils;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import static softuni.exam.util.Constants.*;

// TODO: Implement all methods
@Service
public class ConstellationServiceImpl implements ConstellationService {
    private final ConstellationRepository constellationRepository;
    private final Gson gson;
    private final ModelMapper modelMapper;
    private final ValidationUtils validationUtils;


    public ConstellationServiceImpl(ConstellationRepository constellationRepository, Gson gson, ModelMapper modelMapper, ValidationUtils validationUtils) {
        this.constellationRepository = constellationRepository;
        this.gson = gson;
        this.modelMapper = modelMapper;
        this.validationUtils = validationUtils;
    }


    @Override
    public boolean areImported() {
        return this.constellationRepository.count()>0;
    }

    @Override
    public String readConstellationsFromFile() throws IOException {
        return Files.readString(Path.of(CONSTELLATIONS_URL));
    }

    @Override
    public String importConstellations() throws IOException {
        StringBuilder sb = new StringBuilder();
        List<ConstellationImportDTO> constellationImportDTOS = Arrays.stream(gson.fromJson(readConstellationsFromFile(), ConstellationImportDTO[].class)).collect(Collectors.toList());
        for(ConstellationImportDTO constellationImportDTO : constellationImportDTOS){

            Optional<Constellation> constellationOptional = this.constellationRepository.findFirstByName(constellationImportDTO.getName());
            if(constellationOptional.isPresent() || !validationUtils.isValid(constellationImportDTO)){
                sb.append(String.format(INVALID_FORMAT, CONSTELLATION));
            }
            else{
                Constellation constellation = modelMapper.map(constellationImportDTO, Constellation.class);
                this.constellationRepository.save(constellation);
                sb.append(String.format(SUCCESSFUL_CONSTELLATION, constellation.getName(), constellation.getDescription()));
            }
            sb.append(System.lineSeparator());
        }

        return sb.toString();
    }
}
