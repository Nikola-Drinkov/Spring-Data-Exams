package softuni.exam.util;

public enum Constants {
    ;
    public static final String CONSTELLATIONS_URL = "src/main/resources/files/json/constellations.json";
    public static final String STARS_URL = "src/main/resources/files/json/stars.json";
    public static final String ASTRONOMERS_URL = "src/main/resources/files/xml/astronomers.xml";

    public static final String INVALID_FORMAT = "Invalid %s";
    public static final String CONSTELLATION = "constellation";
    public static final String STAR = "star";
    public static final String ASTRONOMER = "astronomer";

    public static final String SUCCESSFUL_CONSTELLATION = "Successfully imported constellation %s - %s";
    public static final String SUCCESSFUL_STAR = "Successfully imported star %s - %.2f light years";
    public static final String SUCCESSFUL_ASTRONOMER = "Successfully imported astronomer %s %s - %.2f";

}
