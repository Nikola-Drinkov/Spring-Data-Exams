package softuni.exam.models.dto;

import softuni.exam.models.entity.Constellation;

public class StarExportDTO {
    private String name;
    private Double lightYears;
    private String description;
    private String constellation;

    public StarExportDTO(String name, Double lightYears, String description, String constellation) {
        this.name = name;
        this.lightYears = lightYears;
        this.description = description;
        this.constellation = constellation;
    }

    @Override
    public String toString() {
        return String.format("Star: %s\n" +
                "   *Distance: %.2f light years\n" +
                "   **Description: %s\n" +
                "   ***Constellation: %s\n",
                name,
                lightYears,
                description,
                constellation);
    }
}
